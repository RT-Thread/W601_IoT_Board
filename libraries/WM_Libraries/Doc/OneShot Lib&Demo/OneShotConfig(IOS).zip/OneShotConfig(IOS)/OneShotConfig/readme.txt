OneShotConfig项目，打包生成ipa文件时步骤如下：
选中任务栏的produce -->archive,即可打包完成。
选中任务栏window--->organizer-->export-->save for ios APP Deloyment，
选中描述信息,导出IPA包完成.

