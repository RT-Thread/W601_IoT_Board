//
//  Header.h
//  OneShotConfig
//
//  Created by codebat on 7/14/16.
//  Copyright (c) 2016 Netcent. All rights reserved.
//

#ifndef OneShotConfig_Header_h
#define OneShotConfig_Header_h


#endif
